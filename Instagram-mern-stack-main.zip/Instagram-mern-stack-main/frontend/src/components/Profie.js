import React from "react";

export default function Profie() {
  return <div>Profie</div>;
}
